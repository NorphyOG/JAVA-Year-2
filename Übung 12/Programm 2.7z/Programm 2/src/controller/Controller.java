package controller;

import view.Aufgabe2;
import view.TestFenster;

public class Controller {
    public static void main(String[] args) {
        //TestFenster testFenster = new TestFenster();
        Aufgabe2 fenster = new Aufgabe2();
    }
}
