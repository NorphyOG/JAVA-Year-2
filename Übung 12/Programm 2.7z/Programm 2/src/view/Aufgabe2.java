package view;

import javax.swing.*;
import java.awt.*;

public class Aufgabe2 extends JFrame {

    private JLabel eingabe;
    private JTextField eingabe_text;
    private JLabel ausgabe;
    private JTextField ausgabe_text;

    private JButton button1;
    private JButton button2;

    public Aufgabe2() {
        super("In Großbuschstaben umwandeln");

        setSize(550, 129);

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        JPanel pEinAusFeld = new JPanel();

        //Einagbe
        JPanel pEingabeFeld = new JPanel();
        eingabe = new JLabel("Eingabe: ");
        pEingabeFeld.add(eingabe);
        eingabe_text = new JTextField(15);
        pEingabeFeld.add(eingabe_text);
        pEinAusFeld.add(pEingabeFeld, BorderLayout.WEST);

        //Ausgabe
        JPanel pAusgabeFeld = new JPanel();
        ausgabe = new JLabel("Ausgabe: ");
        pAusgabeFeld.add(ausgabe);
        ausgabe_text = new JTextField(15);
        pAusgabeFeld.add(ausgabe_text);
        pEinAusFeld.add(pAusgabeFeld, BorderLayout.EAST);

        container.add(pEinAusFeld, BorderLayout.NORTH);

        JPanel pButtons = new JPanel();

        //Button 1
        button1 = new JButton("In Großbuchstaben");
        pButtons.add(button1, BorderLayout.WEST);

        //Button 2
        button2 = new JButton("Beenden");
        pButtons.add(button2, BorderLayout.EAST);

        container.add(pButtons, BorderLayout.SOUTH);


        setVisible(true);
    }

}
