package main;

public interface MusicalInstrument {
    String playInstrument();
}
