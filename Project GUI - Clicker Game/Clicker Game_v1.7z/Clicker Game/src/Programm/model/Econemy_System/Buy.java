package Programm.model.Econemy_System;

////
///
// Creator: Jerome Weber
// Project: Clicker Game
// Date: 24.03.2022 - 10:23
// Info: For questions or similar contact me on Discord.
// Discord: Ɲorphy#1164
///
////

import Programm.model.InfoUpdate;
import Programm.model.Model;
import Programm.view.CubeKlicker;
import Programm.view.Farmer;

public class Buy {
    private final Model model;

    public Buy(Model model) {
        this.model = model;
    }

    public void buyFarmer(int pos, CubeKlicker cubeKlicker) {

        double multiplikatorStage1 = 1.01;

        Farmer farmer = cubeKlicker.getFarmerList()[pos];

        if (model.getFarmerModels()[pos].getLevel() == 0 && model.getFarmerModels()[pos].getPreis() <= model.getCubes()) {
            model.getFarmerModels()[pos].setLevel(1);
            model.getFarmerModels()[pos].start();
            farmer.getbFarmer().setText("Buy - " + model.getBuyCount() + "x");
            model.setCubes(model.getCubes() - model.getFarmerModels()[pos].getPreis());
            cubeKlicker.getlCubes().setText("Cubes: " + InfoUpdate.getNummerFormart(model.getCubes()) + "⊡");

            model.getFarmerModels()[pos].setPreis(model.getFarmerModels()[pos].getPreis() * 2);
            farmer.getlFarmerPreis().setText(InfoUpdate.getNummerFormart(model.getFarmerModels()[pos].getPreis()) + "⊡");

        } else if (model.getFarmerModels()[pos].getLevel() <= 500 && model.getFarmerModels()[pos].getPreis() <= model.getCubes()) { //Stage 1
            model.getFarmerModels()[pos].setLevel(model.getFarmerModels()[pos].getLevel() + 1); //TODO buyCount

            model.getFarmerModels()[pos].setCubesPerSec((long) (model.getFarmerModels()[pos].getCubesPerSec() + (multiplikatorStage1 + model.getPrestige()) * model.getFarmerModels()[pos].getLevel()));
            model.setCubes(model.getCubes() - model.getFarmerModels()[pos].getPreis());
            cubeKlicker.getlCubes().setText("Cubes: " + InfoUpdate.getNummerFormart(model.getCubes()) + "⊡");

            model.getFarmerModels()[pos].setPreis((long) (model.getFarmerModels()[pos].getPreis() * 1.2));
            farmer.getlFarmerPreis().setText(InfoUpdate.getNummerFormart(model.getFarmerModels()[pos].getPreis()) + "⊡");

        }


        if (pos == 0) {


        } else if (pos == 1) {

        }

    }

    public void multiButton(CubeKlicker cubeKlicker) {


        for (Farmer farmer : cubeKlicker.getFarmerList()) {
            if (!farmer.getbFarmer().getText().equalsIgnoreCase("Unlock")) {

                switch (model.getMbCount()) {
                    case 0 -> { //buy 1x

                        cubeKlicker.getbMultiBuy().setText("Switch to Buy 10x");
                        farmer.getbFarmer().setText("Buy - 1x");
                        model.setBuyCount(1);
                    }
                    case 1 -> { //buy 10x

                        cubeKlicker.getbMultiBuy().setText("Switch to Buy 100x");
                        farmer.getbFarmer().setText("Buy - 10x");
                        model.setBuyCount(10);
                    }
                    case 2 -> { //buy 100x

                        cubeKlicker.getbMultiBuy().setText("Switch to Buy 1000x");
                        farmer.getbFarmer().setText("Buy - 100x");
                        model.setBuyCount(100);
                    }
                    case 3 -> { //buy 1000x

                        cubeKlicker.getbMultiBuy().setText("Switch to Buy 1x");
                        farmer.getbFarmer().setText("Buy - 1000x");
                        model.setBuyCount(1000);
                    }
                }

            }
        }

        model.setMbCount(model.getMbCount() + 1);
        if (model.getMbCount() == 4) {
            model.setMbCount(0);
        }

    }
}