package main;

public class frachtSchiff extends schiff {

    private int maxLadekapaziät;
    private int lademenge;

    public frachtSchiff(String schiffsname, person kapitän, int besatzung, int maxLadekapaziät, int lademenge) {
        super(schiffsname, kapitän, besatzung);
        this.maxLadekapaziät = maxLadekapaziät;
        this.lademenge = lademenge;
    }

    public String info() {
        return "Schiff Name: " + getSchiffsname() + "\nKapitän: " + getKapitän().toString() + "\nBesatzungs Menge: " + getBesatzung() + "\nSchiff ID: " + getSchiffsID() + "\nMaximale Ladekapazität: " + getMaxLadekapaziät() + "\nAktuelle Lademenge: " + getLademenge();
    }

    public boolean beladen(int menge) {
        if (menge <= (getMaxLadekapaziät() - getLademenge())) {
            setLademenge(getLademenge() + menge);
            return true;
        } else {
            return false;
        }
    }

    public boolean entladen(int menge) {
        if (getLademenge() >= menge) {
            setLademenge(getLademenge() - menge);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "frachtSchiff{" +
                "maxLadekapaziät=" + maxLadekapaziät +
                ", lademenge=" + lademenge +
                '}';
    }

    public int getMaxLadekapaziät() {
        return maxLadekapaziät;
    }

    public void setMaxLadekapaziät(int maxLadekapaziät) {
        this.maxLadekapaziät = maxLadekapaziät;
    }

    public int getLademenge() {
        return lademenge;
    }

    public void setLademenge(int lademenge) {
        this.lademenge = lademenge;
    }
}
