package main;

import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;

public class ausflugsboot extends schiff {

    private person[] passagierListe = new person[20];


    public ausflugsboot(String schiffsname, person kapitän, int besatzung) {
        super(schiffsname, kapitän, besatzung);
    }

    public String info() {
        return "Schiffsname: " + getSchiffsname() + "\nKapitän: " + getKapitän().toString() + "\nBesatzungs Menge: " + getBesatzung() + "\nSchiff ID: " + getSchiffsID() + "\nPassagier Liste: " + Arrays.toString(getPassagierListe());
    }

    public double mittelAlter() {
        double a = 0, turn = 0;
        for (main.person person : passagierListe) {
            if (person != null) {
                LocalDate now = LocalDate.now();
                Period per = Period.between(person.getGeburtstag(), now);
                a = a + per.getYears();
                turn = turn + 1;
            }
        }
        return a / turn;
    }

    public boolean addPassagier(person person) {
        for (int i = 0; i < passagierListe.length; i++) {
            if (passagierListe[i] == null) {
                passagierListe[i] = person;
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "ausflugsboot{" +
                "passagierListe=" + Arrays.toString(passagierListe) +
                '}';
    }

    public person[] getPassagierListe() {
        return passagierListe;
    }

    public void setPassagierListe(person[] passagierListe) {
        this.passagierListe = passagierListe;
    }
}
