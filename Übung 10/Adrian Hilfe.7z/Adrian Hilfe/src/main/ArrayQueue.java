package main;

public interface ArrayQueue {

    void create(int groesse);
    boolean isEmpty();
    int remove();
    boolean add(int zahl);
    String show();

}
