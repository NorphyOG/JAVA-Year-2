package main;

public class Reader {

    public void createMyData() {
        //TODO [Aufgabe 1] txt Erstellen mit daten
    }

    public void myData(AQueue aQueue) {
        //TODO [Aufgabe 2] Daten automatisch in die ArrayQueue eintragen
    }

}
