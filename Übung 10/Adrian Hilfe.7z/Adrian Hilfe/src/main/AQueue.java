package main;

public class AQueue  { //TODO [Aufgabe 1] nach AQueue fehlt was (Einziger Fehler)

    private int[] array; //TODO [Aufgabe 1] muss noch definiert werden

    @Override
    public void create(int groesse) {

        //TODO [Aufgabe 1] Erstellt die Array und dazu eine größe. (Damit sie nicht zu groß werden kann begränz es auf 99 und mach ein Default wert falls sie nicht definiert wird)

    }

    @Override
    public boolean isEmpty() {

        //TODO [Aufgabe 1] wenn nix in der Array ist wird "true" ausgegeben, wenn doch dann "false"

        return false; //TODO Return Type
    }

    @Override
    public int remove() {

        //TODO [Aufgabe 1] Gib die erste zahl der Array aus... Danach wird diese gelöscht und aufgerückt auf die erste Position.

        return 0; //TODO Return Type
    }

    @Override
    public boolean add(int zahl) {

        //TODO [Aufgabe 1] Füg eine zahl an die letzte stelle der Array ein

        return false; //TODO Return Type
    }

    @Override
    public String show() {

        //TODO [Aufgabe 1] Array Ausgeben lassen

        return "Return Array"; //TODO Return Type
    }
}
