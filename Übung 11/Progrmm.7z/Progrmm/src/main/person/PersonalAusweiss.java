package main.person;

public interface PersonalAusweiss {

    void newPA(Person person);


}
