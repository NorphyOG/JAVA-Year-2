package controller;

import view.CheckBox;
import view.Login;
import view.Uebersetzer;

public class Controller {
    public static void main(String[] args) {
        //Login login = new Login();
        //Uebersetzer uebersetzer = new Uebersetzer();
        CheckBox checkBox = new CheckBox();
    }
}
